package com.anandu.mygymtracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private val groups = listOf("Back & Biceps", "Chest & Triceps", "Shoulder & Traps", "Legs + Core", "Cardio & Abs")
private val groupColors = mapOf(
    groups[0] to Color(0xFF3986D8), groups[1] to Color(0xFFE56B6F),
    groups[2] to Color(0xFFA477D5), groups[3] to Color(0xFF35A78A), groups[4] to Color(0xFFE3A33D)
)
private val library = mapOf(
    groups[0] to listOf("Lat pulldown – wide grip", "Lat pulldown – neutral grip", "Seated cable row – close grip", "Seated cable row – wide grip", "Chest-supported row", "T-bar row", "Straight-arm pulldown", "Dumbbell curl", "Hammer curl", "Preacher curl", "Cable curl", "Reverse curl"),
    groups[1] to listOf("Bench press", "Incline dumbbell press", "Decline press", "Chest press machine", "Pec deck fly", "Cable crossover", "Incline cable fly", "Triceps pushdown", "Overhead triceps extension", "Skull crusher", "Close-grip bench press"),
    groups[2] to listOf("Shoulder press", "Seated dumbbell shoulder press", "Dumbbell lateral raise", "Cable lateral raise", "Reverse pec deck", "Face pull", "Dumbbell shrug", "Upright row", "Front raise"),
    groups[3] to listOf("Leg extension", "Seated leg curl", "Lying leg curl", "Leg press", "Glute bridge", "Calf raise", "Abdominal crunch", "Plank", "Seated knee raise", "Cable crunch"),
    groups[4] to listOf("Seated ski erg", "Arm ergometer", "Recumbent cycle", "Seated rowing machine", "Seated battle rope", "Abdominal crunch", "Cable wood chop", "Dead bug")
)
private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)
private fun groupColor(group: String) = groupColors[group] ?: Color(0xFF888888)

data class SetDraft(val reps: String = "12", val kg: String = "", val minutes: String = "")
data class ExerciseDraft(val name: String, val sets: List<SetDraft> = listOf(SetDraft(), SetDraft(), SetDraft()))
data class ExerciseRecord(val id: Long, val name: String, val sets: List<SetRecord>)
data class SetRecord(val id: Long, val number: Int, val reps: Int, val kg: Double, val minutes: Int)
data class SessionRecord(val id: Long, val date: String, val group: String, val notes: String, val exercises: List<ExerciseRecord>)

class GymDb(ctx: Context) : SQLiteOpenHelper(ctx, "gym_tracker.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE workouts(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, muscle TEXT, exercise TEXT, sets INTEGER, reps INTEGER, kg REAL, duration INTEGER)")
        db.execSQL("CREATE TABLE meals(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, food TEXT, calories INTEGER, protein REAL)")
        db.execSQL("CREATE TABLE body(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, weight REAL, waist REAL)")
        createSessionTables(db)
    }
    private fun createSessionTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, muscle TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '')")
        db.execSQL("CREATE TABLE IF NOT EXISTS session_exercises(id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER NOT NULL, name TEXT NOT NULL, position INTEGER NOT NULL, FOREIGN KEY(session_id) REFERENCES sessions(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE IF NOT EXISTS exercise_sets(id INTEGER PRIMARY KEY AUTOINCREMENT, exercise_id INTEGER NOT NULL, set_number INTEGER NOT NULL, reps INTEGER NOT NULL DEFAULT 0, kg REAL NOT NULL DEFAULT 0, minutes INTEGER NOT NULL DEFAULT 0, FOREIGN KEY(exercise_id) REFERENCES session_exercises(id) ON DELETE CASCADE)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            createSessionTables(db)
            // Preserve every workout row created by version 1 as a session in version 2.
            db.rawQuery("SELECT date,muscle,exercise,sets,reps,kg,duration FROM workouts ORDER BY id", null).use { c ->
                while (c.moveToNext()) {
                    val s = ContentValues().apply { put("date", c.getString(0) ?: today()); put("muscle", c.getString(1) ?: groups[0]); put("notes", "Migrated from previous version") }
                    val sid = db.insert("sessions", null, s)
                    val e = ContentValues().apply { put("session_id", sid); put("name", c.getString(2) ?: "Exercise"); put("position", 0) }
                    val eid = db.insert("session_exercises", null, e)
                    val count = c.getInt(3).coerceIn(1, 30)
                    for (i in 1..count) {
                        val set = ContentValues().apply { put("exercise_id", eid); put("set_number", i); put("reps", c.getInt(4)); put("kg", c.getDouble(5)); put("minutes", if (i == 1) c.getInt(6) else 0) }
                        db.insert("exercise_sets", null, set)
                    }
                }
            }
        }
    }
    fun saveSession(id: Long?, date: String, group: String, notes: String, exercises: List<ExerciseDraft>): Long {
        val db = writableDatabase; db.beginTransaction()
        try {
            val values = ContentValues().apply { put("date", date); put("muscle", group); put("notes", notes) }
            val sid = if (id == null) db.insertOrThrow("sessions", null, values) else { db.update("sessions", values, "id=?", arrayOf(id.toString())); id }
            if (id != null) {
                val old = mutableListOf<Long>()
                db.rawQuery("SELECT id FROM session_exercises WHERE session_id=?", arrayOf(sid.toString())).use { c -> while (c.moveToNext()) old.add(c.getLong(0)) }
                old.forEach { db.delete("exercise_sets", "exercise_id=?", arrayOf(it.toString())) }
                db.delete("session_exercises", "session_id=?", arrayOf(sid.toString()))
            }
            exercises.forEachIndexed { index, exercise ->
                val ev = ContentValues().apply { put("session_id", sid); put("name", exercise.name); put("position", index) }
                val eid = db.insertOrThrow("session_exercises", null, ev)
                exercise.sets.forEachIndexed { setIndex, set ->
                    val sv = ContentValues().apply { put("exercise_id", eid); put("set_number", setIndex + 1); put("reps", set.reps.toIntOrNull() ?: 0); put("kg", set.kg.toDoubleOrNull() ?: 0.0); put("minutes", set.minutes.toIntOrNull() ?: 0) }
                    db.insert("exercise_sets", null, sv)
                }
            }
            db.setTransactionSuccessful(); return sid
        } finally { db.endTransaction() }
    }
    fun deleteSession(id: Long) {
        val db = writableDatabase; db.beginTransaction()
        try {
            val exerciseIds = mutableListOf<Long>()
            db.rawQuery("SELECT id FROM session_exercises WHERE session_id=?", arrayOf(id.toString())).use { c -> while (c.moveToNext()) exerciseIds.add(c.getLong(0)) }
            exerciseIds.forEach { db.delete("exercise_sets", "exercise_id=?", arrayOf(it.toString())) }
            db.delete("session_exercises", "session_id=?", arrayOf(id.toString()))
            db.delete("sessions", "id=?", arrayOf(id.toString()))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun sessions(): List<SessionRecord> {
        val result = mutableListOf<SessionRecord>()
        readableDatabase.rawQuery("SELECT id,date,muscle,notes FROM sessions ORDER BY date DESC,id DESC", null).use { c ->
            while (c.moveToNext()) {
                val sid = c.getLong(0); val exs = mutableListOf<ExerciseRecord>()
                readableDatabase.rawQuery("SELECT id,name FROM session_exercises WHERE session_id=? ORDER BY position,id", arrayOf(sid.toString())).use { e ->
                    while (e.moveToNext()) {
                        val eid = e.getLong(0); val sets = mutableListOf<SetRecord>()
                        readableDatabase.rawQuery("SELECT id,set_number,reps,kg,minutes FROM exercise_sets WHERE exercise_id=? ORDER BY set_number", arrayOf(eid.toString())).use { s -> while (s.moveToNext()) sets.add(SetRecord(s.getLong(0), s.getInt(1), s.getInt(2), s.getDouble(3), s.getInt(4))) }
                        exs.add(ExerciseRecord(eid, e.getString(1), sets))
                    }
                }
                result.add(SessionRecord(sid, c.getString(1), c.getString(2), c.getString(3), exs))
            }
        }
        return result
    }
    fun previous(name: String): String {
        readableDatabase.rawQuery("SELECT s.date,MAX(t.kg),MAX(t.reps) FROM sessions s JOIN session_exercises e ON e.session_id=s.id JOIN exercise_sets t ON t.exercise_id=e.id WHERE lower(e.name)=lower(?) GROUP BY s.id ORDER BY s.date DESC,s.id DESC LIMIT 1", arrayOf(name)).use { c ->
            return if (c.moveToFirst()) "Last session ${c.getString(0)} • ${c.getDouble(1)} kg • ${c.getInt(2)} reps" else "No previous record for this exercise"
        }
    }
    fun best(name: String): Double? {
        readableDatabase.rawQuery("SELECT MAX(t.kg) FROM session_exercises e JOIN exercise_sets t ON t.exercise_id=e.id WHERE lower(e.name)=lower(?)", arrayOf(name)).use { c -> return if (c.moveToFirst() && !c.isNull(0)) c.getDouble(0) else null }
    }
    fun addMeal(date: String, food: String, calories: Int, protein: Double) { val v = ContentValues().apply { put("date", date); put("food", food); put("calories", calories); put("protein", protein) }; writableDatabase.insert("meals", null, v) }
    fun addBody(date: String, weight: Double, waist: Double) { val v = ContentValues().apply { put("date", date); put("weight", weight); put("waist", waist) }; writableDatabase.insert("body", null, v) }
    fun rows(table: String): List<Map<String, String>> { val out = mutableListOf<Map<String, String>>(); readableDatabase.rawQuery("SELECT * FROM $table ORDER BY date DESC,id DESC", null).use { c -> while (c.moveToNext()) { val m = mutableMapOf<String, String>(); for (i in 0 until c.columnCount) m[c.getColumnName(i)] = c.getString(i) ?: ""; out.add(m) } }; return out }
    fun totals(date: String): Pair<Int, Double> { readableDatabase.rawQuery("SELECT COALESCE(SUM(calories),0),COALESCE(SUM(protein),0) FROM meals WHERE date=?", arrayOf(date)).use { it.moveToFirst(); return it.getInt(0) to it.getDouble(1) } }
    fun exportJson(): String {
        val root = JSONObject(); val sessionsJson = JSONArray()
        sessions().forEach { s ->
            val so = JSONObject().put("date", s.date).put("muscle", s.group).put("notes", s.notes); val exArr = JSONArray()
            s.exercises.forEach { exercise ->
                val exerciseObject = JSONObject()
                exerciseObject.put("name", exercise.name)
                val setsArray = JSONArray()
                exercise.sets.forEach { workoutSet ->
                    val setObject = JSONObject()
                    setObject.put("reps", workoutSet.reps)
                    setObject.put("kg", workoutSet.kg)
                    setObject.put("minutes", workoutSet.minutes)
                    setsArray.put(setObject)
                }
                exerciseObject.put("sets", setsArray)
                exArr.put(exerciseObject)
            }
            so.put("exercises", exArr); sessionsJson.put(so)
        }
        root.put("sessions", sessionsJson)
        for (table in listOf("meals", "body")) { val arr = JSONArray(); rows(table).forEach { arr.put(JSONObject(it)) }; root.put(table, arr) }
        return root.toString(2)
    }
    fun importJson(json: String) {
        val root = JSONObject(json)
        if (root.has("sessions")) { val arr = root.getJSONArray("sessions"); for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); val exs = mutableListOf<ExerciseDraft>(); val ea = o.optJSONArray("exercises") ?: JSONArray(); for (j in 0 until ea.length()) { val eo = ea.getJSONObject(j); val sets = mutableListOf<SetDraft>(); val sa = eo.optJSONArray("sets") ?: JSONArray(); for (k in 0 until sa.length()) { val st = sa.getJSONObject(k); sets.add(SetDraft(st.optInt("reps").toString(), st.optDouble("kg").takeIf { it != 0.0 }?.toString() ?: "", st.optInt("minutes").takeIf { it != 0 }?.toString() ?: "")) }; exs.add(ExerciseDraft(eo.optString("name"), sets.ifEmpty { listOf(SetDraft()) })) }; saveSession(null, o.optString("date", today()), o.optString("muscle", groups[0]), o.optString("notes"), exs) } }
        // Backward compatibility with v1 backups containing flat workout rows.
        if (root.has("workouts")) { val a = root.getJSONArray("workouts"); for (i in 0 until a.length()) { val o = a.getJSONObject(i); val sets = (1..o.optInt("sets", 1).coerceIn(1, 30)).map { SetDraft(o.optInt("reps").toString(), o.optDouble("kg").toString(), if (it == 1) o.optInt("duration").toString() else "") }; saveSession(null, o.optString("date", today()), o.optString("muscle", groups[0]), "Imported legacy workout", listOf(ExerciseDraft(o.optString("exercise", "Exercise"), sets))) } }
        for (table in listOf("meals", "body")) if (root.has(table)) { val a = root.getJSONArray(table); for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (table == "meals") addMeal(o.optString("date", today()), o.optString("food"), o.optInt("calories"), o.optDouble("protein")) else addBody(o.optString("date", today()), o.optDouble("weight"), o.optDouble("waist")) } }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); val db = GymDb(this); val prefs = getSharedPreferences("settings", MODE_PRIVATE); setContent { GymApp(db, prefs.getBoolean("dark", true), { prefs.edit().putBoolean("dark", it).apply() }) } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun GymApp(db: GymDb, initialDark: Boolean, saveDark: (Boolean) -> Unit) {
    var dark by remember { mutableStateOf(initialDark) }; var tab by remember { mutableIntStateOf(0) }; var refresh by remember { mutableIntStateOf(0) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val backupOut = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> if (uri != null) runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(db.exportJson()) } } }
    val backupIn = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { db.importJson(it.readText()) }; refresh++ } }
    MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
        Scaffold(topBar = { TopAppBar(title = { Text("My Gym Tracker 2.0", fontWeight = FontWeight.SemiBold) }, actions = { IconButton(onClick = { dark = !dark; saveDark(dark) }) { Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme") } }) }, bottomBar = { NavigationBar { listOf("Workout", "Nutrition", "Progress", "Backup").forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(when (i) { 0 -> Icons.Default.FitnessCenter; 1 -> Icons.Default.Restaurant; 2 -> Icons.Default.ShowChart; else -> Icons.Default.Backup }, null) }, label = { Text(label) }) } } }) { pad -> key(refresh) { when (tab) { 0 -> WorkoutScreen(db, Modifier.padding(pad), { refresh++ }); 1 -> NutritionScreen(db, Modifier.padding(pad), { refresh++ }); 2 -> ProgressScreen(db, Modifier.padding(pad)); else -> BackupScreen(Modifier.padding(pad), { backupOut.launch("my_gym_tracker_2_backup.json") }, { backupIn.launch(arrayOf("application/json")) }) } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun WorkoutScreen(db: GymDb, modifier: Modifier, changed: () -> Unit) {
    var date by remember { mutableStateOf(today()) }; var group by remember { mutableStateOf(groups[0]) }; var notes by remember { mutableStateOf("") }
    var sessionId by remember { mutableStateOf<Long?>(null) }; var drafts by remember { mutableStateOf(listOf<ExerciseDraft>()) }
    var exerciseName by remember { mutableStateOf("") }; var groupExpanded by remember { mutableStateOf(false) }; var exerciseExpanded by remember { mutableStateOf(false) }; var showCalendar by remember { mutableStateOf(false) }; var filterDate by remember { mutableStateOf("") }
    val sessions = db.sessions(); val suggestions = library[group].orEmpty().filter { it.contains(exerciseName, true) }
    fun startNew() { sessionId = null; date = today(); group = groups[0]; notes = ""; drafts = emptyList(); exerciseName = "" }
    fun loadSession(s: SessionRecord) { sessionId = s.id; date = s.date; group = s.group; notes = s.notes; drafts = s.exercises.map { e -> ExerciseDraft(e.name, e.sets.map { SetDraft(it.reps.toString(), if (it.kg == 0.0) "" else it.kg.toString(), if (it.minutes == 0) "" else it.minutes.toString()) }.ifEmpty { listOf(SetDraft()) }) }; exerciseName = "" }
    fun updateSet(exIndex: Int, setIndex: Int, value: SetDraft) { drafts = drafts.toMutableList().also { list -> val e = list[exIndex]; list[exIndex] = e.copy(sets = e.sets.toMutableList().also { it[setIndex] = value }) } }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(if (sessionId == null) "Create workout session" else "Edit completed workout", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("One session • multiple exercises • individual sets", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; if (sessionId != null) TextButton(onClick = { startNew() }) { Text("New session") } }
        OutlinedTextField(date, { date = it }, label = { Text("Session date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        ExposedDropdownMenuBox(groupExpanded, { groupExpanded = it }) { OutlinedTextField(group, {}, readOnly = true, label = { Text("Workout muscle group") }, leadingIcon = { Box(Modifier.size(12.dp).background(groupColor(group), RoundedCornerShape(50))) }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(groupExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth()); ExposedDropdownMenu(groupExpanded, { groupExpanded = false }) { groups.forEach { g -> DropdownMenuItem(text = { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(12.dp).background(groupColor(g), RoundedCornerShape(50))); Spacer(Modifier.width(10.dp)); Text(g) } }, onClick = { group = g; groupExpanded = false; exerciseName = "" }) } } }
        OutlinedTextField(exerciseName, { exerciseName = it; exerciseExpanded = true }, label = { Text("Search exercise or enter a custom name") }, modifier = Modifier.fillMaxWidth(), trailingIcon = { IconButton(onClick = { exerciseExpanded = !exerciseExpanded }) { Icon(Icons.Default.ArrowDropDown, null) } })
        if (exerciseExpanded && suggestions.isNotEmpty()) Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(8.dp)) { Text("Exercise library", fontWeight = FontWeight.Bold); suggestions.take(8).forEach { TextButton(onClick = { exerciseName = it; exerciseExpanded = false }) { Text(it) } } } }
        if (exerciseName.isNotBlank()) { Text(db.previous(exerciseName), style = MaterialTheme.typography.bodySmall); Text("Personal best: ${db.best(exerciseName)?.let { "$it kg" } ?: "—"}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold) }
        Button(onClick = { if (exerciseName.isNotBlank()) { drafts = drafts + ExerciseDraft(exerciseName.trim()); exerciseName = ""; exerciseExpanded = false } }, modifier = Modifier.fillMaxWidth(), enabled = exerciseName.isNotBlank()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add exercise to session") }
        if (drafts.isNotEmpty()) {
            Text("Exercises in this session (${drafts.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            drafts.forEachIndexed { ei, ex ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f))) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Text(ex.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); IconButton(onClick = { drafts = drafts.toMutableList().also { it.removeAt(ei) } }) { Icon(Icons.Default.Delete, "Remove exercise", tint = MaterialTheme.colorScheme.error) } }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Set", Modifier.weight(.7f), fontWeight = FontWeight.Bold); Text("Reps", Modifier.weight(1f), fontWeight = FontWeight.Bold); Text("Weight kg", Modifier.weight(1.4f), fontWeight = FontWeight.Bold); Text("Min", Modifier.weight(.8f), fontWeight = FontWeight.Bold) }
                        ex.sets.forEachIndexed { si, set ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text("${si + 1}", Modifier.weight(.7f), fontWeight = FontWeight.Bold)
                                OutlinedTextField(set.reps, { updateSet(ei, si, set.copy(reps = it)) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Reps") })
                                OutlinedTextField(set.kg, { updateSet(ei, si, set.copy(kg = it)) }, modifier = Modifier.weight(1.4f), singleLine = true, label = { Text("kg") })
                                OutlinedTextField(set.minutes, { updateSet(ei, si, set.copy(minutes = it)) }, modifier = Modifier.weight(.8f), singleLine = true, label = { Text("min") })
                                IconButton(onClick = { drafts = drafts.toMutableList().also { list -> list[ei] = ex.copy(sets = ex.sets.toMutableList().also { it.removeAt(si) }) } }, enabled = ex.sets.size > 1) { Icon(Icons.Default.Close, "Remove set") }
                            }
                        }
                        OutlinedButton(onClick = { drafts = drafts.toMutableList().also { it[ei] = ex.copy(sets = ex.sets + SetDraft()) } }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Add set") }
                    }
                }
            }
        }
        OutlinedTextField(notes, { notes = it }, label = { Text("Session notes (optional)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        Button(onClick = { if (date.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) && drafts.isNotEmpty() && drafts.all { it.sets.isNotEmpty() }) { db.saveSession(sessionId, date, group, notes, drafts); startNew(); changed() } }, modifier = Modifier.fillMaxWidth(), enabled = drafts.isNotEmpty()) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text(if (sessionId == null) "Save workout session" else "Update completed workout") }
        if (sessionId != null) OutlinedButton(onClick = { db.deleteSession(sessionId!!); startNew(); changed() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Icon(Icons.Default.Delete, null); Spacer(Modifier.width(8.dp)); Text("Delete this session") }
        HorizontalDivider()
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Workout calendar", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f)); TextButton(onClick = { showCalendar = !showCalendar }) { Text(if (showCalendar) "Hide" else "Show") } }
        if (showCalendar) WorkoutCalendar(sessions) { filterDate = it }
        Row(verticalAlignment = Alignment.CenterVertically) { Text(if (filterDate.isBlank()) "Completed sessions" else "Sessions on $filterDate", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f)); if (filterDate.isNotBlank()) TextButton(onClick = { filterDate = "" }) { Text("Clear") } }
        val visible = sessions.filter { filterDate.isBlank() || it.date == filterDate }
        if (visible.isEmpty()) Text("No saved sessions yet. Add exercises above to start.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        visible.forEach { s ->
            Card(Modifier.fillMaxWidth().clickable { loadSession(s) }) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(10.dp).background(groupColor(s.group), RoundedCornerShape(50))); Spacer(Modifier.width(8.dp)); Text(s.group, color = groupColor(s.group), fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text(s.date, style = MaterialTheme.typography.bodySmall) }
                    Text("${s.exercises.size} exercises • ${s.exercises.sumOf { it.sets.size }} sets", fontWeight = FontWeight.SemiBold)
                    s.exercises.forEach { e -> Text("${e.name}: ${e.sets.joinToString { set -> "${set.kg}kg × ${set.reps}" }}", style = MaterialTheme.typography.bodySmall, maxLines = 2) }
                    Text("Tap to edit this completed workout", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable fun WorkoutCalendar(sessions: List<SessionRecord>, select: (String) -> Unit) {
    var offset by remember { mutableIntStateOf(0) }; val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); add(Calendar.MONTH, offset) }; val year = cal.get(Calendar.YEAR); val month = cal.get(Calendar.MONTH); val first = cal.get(Calendar.DAY_OF_WEEK) - 1; val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH); val counts = sessions.groupingBy { it.date }.eachCount()
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { TextButton(onClick = { offset-- }) { Text("‹ Previous") }; Text(SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time), fontWeight = FontWeight.Bold); TextButton(onClick = { offset++ }) { Text("Next ›") } }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) { listOf("S", "M", "T", "W", "T", "F", "S").forEach { Text(it, fontWeight = FontWeight.Bold) } }
        ((0 until first).map { 0 } + (1..days).toList()).chunked(7).forEach { week -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) { week.forEach { day -> if (day == 0) Spacer(Modifier.weight(1f)) else { val key = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day); val count = counts[key] ?: 0; TextButton(onClick = { select(key) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text(if (count > 0) "$day\n●$count" else day.toString(), color = if (count > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) } } } } }
        Text("Tap a date with a dot to view its workout sessions.", style = MaterialTheme.typography.bodySmall)
    } }
}

@Composable fun NutritionScreen(db: GymDb, modifier: Modifier, changed: () -> Unit) {
    var date by remember { mutableStateOf(today()) }; var food by remember { mutableStateOf("") }; var calories by remember { mutableStateOf("") }; var protein by remember { mutableStateOf("") }; val totals = db.totals(today())
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Nutrition tracker", style = MaterialTheme.typography.titleLarge); Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("Today's intake", style = MaterialTheme.typography.titleMedium); Text("${totals.first} kcal • ${"%.1f".format(totals.second)} g protein", style = MaterialTheme.typography.headlineSmall) } }
        OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(food, { food = it }, label = { Text("Food / meal description") }, modifier = Modifier.fillMaxWidth()); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(calories, { calories = it }, label = { Text("Calories kcal") }, modifier = Modifier.weight(1f)); OutlinedTextField(protein, { protein = it }, label = { Text("Protein g") }, modifier = Modifier.weight(1f)) }
        Button(onClick = { if (food.isNotBlank()) { db.addMeal(date, food, calories.toIntOrNull() ?: 0, protein.toDoubleOrNull() ?: 0.0); food = ""; calories = ""; protein = ""; changed() } }, modifier = Modifier.fillMaxWidth()) { Text("Save food entry") }; HorizontalDivider(); Text("Food history", style = MaterialTheme.typography.titleLarge)
        db.rows("meals").forEach { r -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(r["food"] ?: "", style = MaterialTheme.typography.titleMedium); Text("${r["date"]} | ${r["calories"]} kcal | ${r["protein"]} g protein") } } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ProgressScreen(db: GymDb, modifier: Modifier) {
    var weight by remember { mutableStateOf("") }; var waist by remember { mutableStateOf("") }; var date by remember { mutableStateOf(today()) }; var selected by remember { mutableStateOf("") }; var expanded by remember { mutableStateOf(false) }
    val sessions = db.sessions(); val names = sessions.flatMap { it.exercises }.map { it.name }.distinct().sorted(); val chosen = if (selected.isBlank()) names.firstOrNull().orEmpty() else selected
    val points = sessions.sortedBy { it.date }.mapNotNull { s -> s.exercises.filter { it.name.equals(chosen, true) }.flatMap { it.sets }.mapNotNull { it.kg.takeIf { kg -> kg > 0 } }.maxOrNull()?.let { s.date to it.toFloat() } }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Body & exercise progress", style = MaterialTheme.typography.titleLarge); OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth()); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(weight, { weight = it }, label = { Text("Weight kg") }, modifier = Modifier.weight(1f)); OutlinedTextField(waist, { waist = it }, label = { Text("Waist cm") }, modifier = Modifier.weight(1f)) }
        Button(onClick = { if (weight.toDoubleOrNull() != null) { db.addBody(date, weight.toDouble(), waist.toDoubleOrNull() ?: 0.0); weight = ""; waist = "" } }, modifier = Modifier.fillMaxWidth()) { Text("Save body measurement") }; HorizontalDivider(); Text("Body measurement history", style = MaterialTheme.typography.titleMedium)
        db.rows("body").forEach { r -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) { Text("${r["weight"]} kg", fontWeight = FontWeight.Bold); Text("${r["date"]} | Waist: ${r["waist"]} cm") } } }
        HorizontalDivider(); Text("Exercise weight progression", style = MaterialTheme.typography.titleLarge)
        if (names.isNotEmpty()) {
            ExposedDropdownMenuBox(expanded, { expanded = it }) { OutlinedTextField(chosen, {}, readOnly = true, label = { Text("Select exercise") }, modifier = Modifier.menuAnchor().fillMaxWidth(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }); ExposedDropdownMenu(expanded, { expanded = false }) { names.forEach { n -> DropdownMenuItem(text = { Text(n) }, onClick = { selected = n; expanded = false }) } } }
            if (points.isNotEmpty()) { Text("${points.size} sessions • best recorded set ${points.maxOf { it.second }} kg"); WeightLineChart(points.map { it.second }); points.forEach { Text("${it.first}: ${it.second} kg", style = MaterialTheme.typography.bodySmall) } }
        } else Text("Complete a workout to see exercise progression.")
        HorizontalDivider(); Text("Training summary", style = MaterialTheme.typography.titleMedium); Text("Workout sessions: ${sessions.size}"); Text("Exercises logged: ${sessions.sumOf { it.exercises.size }}"); Text("Sets logged: ${sessions.sumOf { s -> s.exercises.sumOf { it.sets.size } }}"); Text("Workout days: ${sessions.map { it.date }.distinct().size}"); Text("Cardio duration: ${sessions.sumOf { s -> s.exercises.sumOf { e -> e.sets.sumOf { it.minutes } } }} minutes")
    }
}

@Composable fun WeightLineChart(values: List<Float>) {
    val color = MaterialTheme.colorScheme.primary; val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(Modifier.fillMaxWidth().height(170.dp).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .25f), RoundedCornerShape(8.dp)).padding(8.dp)) {
        if (values.isNotEmpty()) { val min = (values.minOrNull() ?: 0f) - 1f; val max = (values.maxOrNull() ?: 1f) + 1f; val range = (max - min).coerceAtLeast(1f); val left = 12f; val right = size.width - 12f; val top = 12f; val bottom = size.height - 12f; for (i in 0..3) { val y = top + (bottom - top) * i / 3; drawLine(grid, Offset(left, y), Offset(right, y), 1f) }; val pts = values.mapIndexed { idx, v -> Offset(if (values.size == 1) (left + right) / 2 else left + (right - left) * idx / (values.size - 1), bottom - (v - min) / range * (bottom - top)) }; pts.zipWithNext().forEach { (a, b) -> drawLine(color, a, b, 4f, cap = StrokeCap.Round) }; pts.forEach { drawCircle(color, 5f, it) } }
    }
}

@Composable fun BackupScreen(modifier: Modifier, export: () -> Unit, import: () -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) { Text("Backup & restore", style = MaterialTheme.typography.titleLarge); Text("Your sessions, individual sets, food diary and body measurements are stored locally on this phone. Export a JSON backup to phone storage or a cloud drive you choose."); Button(onClick = export, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileUpload, null); Spacer(Modifier.width(8.dp)); Text("Export backup") }; OutlinedButton(onClick = import, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("Restore from backup") }; Text("Restore adds records to existing data. Avoid importing the same backup more than once. Export a backup before uninstalling or updating the app."); Text("No account or internet permission is required. Use the sun/moon icon to change appearance.") }
}
